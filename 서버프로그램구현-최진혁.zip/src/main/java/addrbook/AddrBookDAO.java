package addrbook;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class AddrBookDAO {
	private Connection conn;
	private PreparedStatement pstmt;
	private ResultSet rs;
		
	//		---------- DB���� ----------  //
	public AddrBookDAO() {
		try {
			String dbURL = "jdbc:mysql://localhost:3306/addrbook";//mysql ��ġ
			String dbID = "root";//mysql ID
			String dbPassword = "root";//mysql PASSWORD
			Class.forName("com.mysql.cj.jdbc.Driver");//���� ����̹�
			conn=DriverManager.getConnection(dbURL, dbID, dbPassword);//DB�������� �� ����
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public ArrayList<AddrBook> getDBList() {
		ArrayList<AddrBook> datas = new ArrayList<AddrBook>();
		
		String sql = "select * from user order by addr_id desc";
		try {
			PreparedStatement pstmt=conn.prepareStatement(sql);
			rs=pstmt.executeQuery();
			while(rs.next()) {
				AddrBook addrbook = new AddrBook();
				addrbook.setAb_id(rs.getInt(1));
				addrbook.setAb_name(rs.getString(2));
				addrbook.setAb_tel(rs.getString(3));
				addrbook.setAb_memo(rs.getString(4));
				datas.add(addrbook);
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return datas;
	}
	
	public boolean deleteDB(int gb_id) {
		String sql = "delete from user where addr_id=?";
		try {
			PreparedStatement pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1,  gb_id);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public boolean insertDB(AddrBook addrbook) {
		String sql = "insert into user(addr_name, addr_tel, addr_memo) values (?,?,?)";
		try {
			PreparedStatement pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, addrbook.getAb_name());
			pstmt.setString(2, addrbook.getAb_tel());
			pstmt.setString(3, addrbook.getAb_memo());
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public ArrayList<AddrBook> getDB(String ab_name) {
		String sql = "select * from user where addr_name like '%" + ab_name + "%'";
		ArrayList<AddrBook> addrbook = new ArrayList<AddrBook>();
		try {
			PreparedStatement pstmt=conn.prepareStatement(sql);
			//pstmt.setString(1, ab_name);
			ResultSet rs = pstmt.executeQuery();
			
			while(rs.next()) {
				AddrBook addrbook2 = new AddrBook();
				addrbook2.setAb_id(rs.getInt(1));
				addrbook2.setAb_name(rs.getString(2));
				addrbook2.setAb_tel(rs.getString(3));
				addrbook2.setAb_memo(rs.getString(4));
				addrbook.add(addrbook2);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return addrbook;
		
	}
}
