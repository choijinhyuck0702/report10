package addrbook;

public class AddrBook {
	private int ab_id;
	private String ab_name;
	private String ab_tel;
	private String ab_memo;
	public int getAb_id() {
		return ab_id;
	}
	public void setAb_id(int ab_id) {
		this.ab_id = ab_id;
	}
	public String getAb_name() {
		return ab_name;
	}
	public void setAb_name(String ab_name) {
		this.ab_name = ab_name;
	}
	public String getAb_tel() {
		return ab_tel;
	}
	public void setAb_tel(String ab_tel) {
		this.ab_tel = ab_tel;
	}
	public String getAb_memo() {
		return ab_memo;
	}
	public void setAb_memo(String ab_memo) {
		this.ab_memo = ab_memo;
	}
	
	
}
